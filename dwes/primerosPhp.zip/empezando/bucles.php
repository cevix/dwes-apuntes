<?php

echo "<meta charset='utf-8'>";

echo "<h2>comparacion(igualdad)<h2>";

echo "<h2>for(igualdad)<h2>";

for ($i=0; $i <10 ; $i++) { 
	echo "<h2>buenos dias<h2>";
}


echo "while";

$i=1;
while ( $i <= 10) {
	echo "<p>nuenos dias</p>";
	$i=+1;
}

?>
