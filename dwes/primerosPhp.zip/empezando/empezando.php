<?php 

echo "<h1>hola mundo</h1>";



?>