<?php
//esto es una asignación
$numero=7;
$numero2=17;
echo "<p> El contenido de la variable es: $numero</p>";
echo "<p> El contenido de la variable es: ".$numero,$numero2."</p>";
echo '<p> El contenido de la variable $numero es: '.$numero."</p>";
//php es sencible a mayusculas
$numero="pepe";
echo "<p> El contenido de la variable es: $numero</p>";
echo "<p> El contenido de la variable es: ".$numero."</p>";
echo '<p> El contenido de la variable $numero es: '.$numero."</p>";



?>
