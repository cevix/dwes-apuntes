<?php 

$resultado=1%2;
echo $resultado;

?>